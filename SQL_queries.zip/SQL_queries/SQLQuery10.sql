USE employee; 
SELECT EMP_ID,FIRST_NAME,DEPT,EXP,DENSE_RANK() OVER(order by exp desc) as "EMP_EXP_DENSE_RANK"from emp_record_table -- Query for task 10