USE employee;
GO

-- Drop the procedure if it exists
IF OBJECT_ID('ExperiencedEmployees', 'P') IS NOT NULL
    DROP PROCEDURE ExperiencedEmployees;
GO

-- Create the stored procedure
CREATE PROCEDURE ExperiencedEmployees
AS
BEGIN
    SELECT EMP_ID, FIRST_NAME, LAST_NAME, EXP
    FROM emp_record_table
    WHERE EXP > 3;
END;
GO

USE employee;
EXEC ExperiencedEmployees;

