Select *
 from [dbo].[emp_record_table]
 where exp in ( select exp from [dbo].[emp_record_table]
 where exp>10);