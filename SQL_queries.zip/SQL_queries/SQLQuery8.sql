USE employee;
SELECT  EMP_ID, FIRST_NAME,LAST_NAME,role,DEPT,EMP_RATING ,max(EMP_RATING)
OVER(PARTITION BY DEPT)
AS "Max_Dept_Rating"
FROM [dbo].[emp_record_table]
ORDER BY DEPT asc; -- Query for task 8