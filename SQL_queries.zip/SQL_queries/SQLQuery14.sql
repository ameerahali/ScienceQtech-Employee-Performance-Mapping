USE employee;
GO

-- Drop the function if it exists
IF OBJECT_ID('GetJobProfile', 'FN') IS NOT NULL
    DROP FUNCTION GetJobProfile;
GO

-- Create the function
CREATE FUNCTION GetJobProfile(@EXPERIENCE INT)
RETURNS NVARCHAR(50)
AS
BEGIN
    DECLARE @JOB_PROFILE NVARCHAR(50);
    
    IF @EXPERIENCE <= 2
        SET @JOB_PROFILE = 'JUNIOR DATA SCIENTIST';
    ELSE IF @EXPERIENCE <= 5
        SET @JOB_PROFILE = 'ASSOCIATE DATA SCIENTIST';
    ELSE IF @EXPERIENCE <= 10
        SET @JOB_PROFILE = 'SENIOR DATA SCIENTIST';
    ELSE IF @EXPERIENCE <= 12
        SET @JOB_PROFILE = 'LEAD DATA SCIENTIST';
    ELSE IF @EXPERIENCE <= 16 
        SET @JOB_PROFILE = 'MANAGER';
    
    RETURN @JOB_PROFILE;
END;
GO
USE employee;

SELECT EMP_ID, FIRST_NAME, LAST_NAME, EXP, dbo.GetJobProfile(EXP) AS Job_Profile
FROM emp_record_table;
