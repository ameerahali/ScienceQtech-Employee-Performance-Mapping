select emp_id ,emp_rating,salary , ((salary*0.05)* emp_rating) as Bouns ,  ((salary*0.05)* emp_rating)+ salary as "Salary after Bouns"
from emp_record_table;