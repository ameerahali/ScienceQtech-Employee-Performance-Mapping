USE employee; 

select  e1.emp_id , e1.FIRST_NAME,e1.LAST_NAME, e1.GENDER, e1.ROLE, e1.DEPT,e1.EXP,count(e2.EMP_ID) as "Count of Emp"
from employees.emp_record_table e1
 join employees.emp_record_table e2
on (e1.emp_id=e2.MANAGER_ID)
group by e1.EMP_ID
order by e1.EMP_ID;