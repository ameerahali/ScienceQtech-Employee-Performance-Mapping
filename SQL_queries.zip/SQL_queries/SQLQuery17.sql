select Country, CONTINENT , avg(salary) as avg_salary 
from  emp_record_table
group by   Country, CONTINENT 
order by   Country,CONTINENT asc;