USE employee; 

SELECT ROLE,
       MIN(SALARY) AS Min_Salary,
       MAX(SALARY) AS Max_Salary
FROM emp_record_table
GROUP BY ROLE; -- Query for task 9
