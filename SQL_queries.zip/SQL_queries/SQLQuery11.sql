Create view various_countries
 as select EMP_ID,FIRST_NAME,LAST_NAME,SALARY, COUNTRY
 from employees.emp_record_table
 where salary > 6000;
 
 SELECT * FROM various_countries;